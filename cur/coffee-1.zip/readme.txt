﻿=== Coffee Cursor Set ===

By: MintPepper (http://www.rw-designer.com/user/61590)

Download: http://www.rw-designer.com/cursor-set/coffee-1

Author's description:

Sometimes, you need to relax and drink some coffee.
brew some coffee before using a computer.
If you cannot brew a cup of coffee, this is what you need.

==========

License: Custom

You are free:

* To Use the work for personal noncommercial purposes.

For any other use, you must contact the author and ask for permission.